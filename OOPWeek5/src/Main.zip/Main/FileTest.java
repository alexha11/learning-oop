package Main;

import java.io.*;

public class FileTest {

//    public void saveData(String filename){
//        try {
//            FileOutputStream fileOut = new FileOutputStream(filename);
//            ObjectOutputStream out = new ObjectOutputStream(fileOut);
//            out.writeObject(zoo);
//            System.out.println("duong");
//            out.close();
//            fileOut.close();
//            System.out.println("Zoo has been saved.");
//        }
//        catch(IOException ex)
//        {
//            System.out.println("Zoo has been saved.");
//        }
//    }

//    public static Zoo loadData(String filename){
//        try {
//            FileTest file  = new FileTest(filename);
//            FileInputStream fileIn = new FileInputStream(file);
//            ObjectInputStream in = new ObjectInputStream(fileIn);
//            Zoo zoo = (Zoo) in.readObject();
//            in.close();
//            fileIn.close();
//            System.out.println("Zoo has been loaded from a file.");
//        }
//        catch(IOException ex)
//        {
//            System.out.println("IOException is caught");
//        }
//        catch(ClassNotFoundException ex)
//        {
//            System.out.println("ClassNotFoundException is caught");
//        }
//    }
}
