package Main;

public interface Jumpable {
    public void jump();
    public void land();
}
