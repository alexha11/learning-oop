package Main;

public class ReservedNameException extends Exception {
    public ReservedNameException(String message) {
        super(message);
    }
}
